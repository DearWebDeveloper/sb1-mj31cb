import React, { createContext, useContext, useState, useEffect } from 'react'

const ProjectContext = createContext(null)

export const useProjectContext = () => useContext(ProjectContext)

export const ProjectProvider = ({ children }) => {
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        // Simulated API call
        const response = await new Promise(resolve => 
          setTimeout(() => resolve([
            {
              id: 1,
              name: 'Water Damage Restoration - 123 Main St',
              type: 'Water Damage',
              status: 'In Progress',
            },
            {
              id: 2,
              name: 'Mold Remediation - 456 Elm St',
              type: 'Mold',
              status: 'Completed',
            },
          ]), 1000)
        )
        setProjects(response)
        setLoading(false)
      } catch (err) {
        setError('Failed to fetch projects')
        setLoading(false)
      }
    }

    fetchProjects()
  }, [])

  const addProject = (project) => {
    setProjects([...projects, { ...project, id: Date.now() }])
  }

  const updateProject = (updatedProject) => {
    setProjects(projects.map(project => 
      project.id === updatedProject.id ? updatedProject : project
    ))
  }

  const deleteProject = (id) => {
    setProjects(projects.filter(project => project.id !== id))
  }

  return (
    <ProjectContext.Provider value={{ projects, loading, error, addProject, updateProject, deleteProject }}>
      {children}
    </ProjectContext.Provider>
  )
}