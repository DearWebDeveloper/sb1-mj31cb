import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Camera, FileText, Clipboard, Wrench, BarChart2, Droplet, Edit, Save, X, AlertCircle, CheckCircle } from 'lucide-react'

const ProjectDetail = () => {
  const { id } = useParams()
  const [project, setProject] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [newNote, setNewNote] = useState('')
  const [isEditing, setIsEditing] = useState(false)
  const [editedProject, setEditedProject] = useState(null)
  const [complianceChecks, setComplianceChecks] = useState([])

  useEffect(() => {
    const fetchProjectDetails = async () => {
      try {
        // Simulated API call
        const projectData = {
          id: parseInt(id),
          name: 'Water Damage Restoration - 123 Main St',
          type: 'Water Mitigation',
          category: 'Category 2',
          insuranceCarrier: 'ABC Insurance',
          claimNumber: 'WD12345',
          dateOfLoss: '2023-04-01',
          status: 'In Progress',
          streetAddress: '123 Main St',
          city: 'Anytown',
          state: 'CA',
          zipCode: '12345',
          sourceOfLoss: 'Pipe Burst',
          customerCalled: { timestamp: '2023-04-01T08:00:00Z', user: 'john@example.com' },
          siteInspected: { timestamp: '2023-04-01T10:00:00Z', user: 'jane@example.com' },
          completed: null,
          affectedRooms: [
            { id: 1, name: 'Living Room', floorLevel: 1, length: 20, width: 15, height: 8, affectedFloorSF: 300, affectedWallSF: 200, affectedCeilingSF: 300 },
            { id: 2, name: 'Kitchen', floorLevel: 1, length: 12, width: 10, height: 8, affectedFloorSF: 120, affectedWallSF: 100, affectedCeilingSF: 120 },
          ],
          notes: [
            { id: 1, text: 'Initial assessment completed', timestamp: '2023-04-01T11:00:00Z', user: 'jane@example.com' },
            { id: 2, text: 'Equipment set up', timestamp: '2023-04-01T14:00:00Z', user: 'mike@example.com' },
          ],
          photos: [],
          equipment: [
            { id: 1, type: 'Dehumidifier', model: 'DH-2000', serialNumber: 'DH2000-001', roomId: 1, startTimestamp: '2023-04-01T15:00:00Z', endTimestamp: null },
            { id: 2, type: 'Air Mover', model: 'AM-500', serialNumber: 'AM500-001', roomId: 1, startTimestamp: '2023-04-01T15:30:00Z', endTimestamp: null },
          ],
        }
        setProject(projectData)
        setEditedProject(projectData)
        setLoading(false)

        // Simulated compliance checks
        const complianceData = [
          { id: 1, description: 'Initial inspection completed', status: 'Completed' },
          { id: 2, description: 'Equipment placement documented', status: 'Completed' },
          { id: 3, description: 'Daily moisture readings recorded', status: 'Pending' },
          { id: 4, description: 'Final inspection report generated', status: 'Pending' },
        ]
        setComplianceChecks(complianceData)
      } catch (err) {
        setError('Failed to fetch project details')
        setLoading(false)
      }
    }

    fetchProjectDetails()
  }, [id])

  const addNote = () => {
    if (newNote.trim() === '') return
    const newNoteObj = {
      id: project.notes.length + 1,
      text: newNote,
      timestamp: new Date().toISOString(),
      user: 'currentUser@example.com', // This should be replaced with the actual logged-in user
    }
    setProject({ ...project, notes: [...project.notes, newNoteObj] })
    setNewNote('')
  }

  const handleEdit = () => {
    setIsEditing(true)
  }

  const handleSave = () => {
    // Here you would typically make an API call to update the project
    setProject(editedProject)
    setIsEditing(false)
    // Check if completion date is set and update status
    if (editedProject.completed && editedProject.status !== 'Completed') {
      setProject({ ...editedProject, status: 'Completed' })
    }
  }

  const handleCancel = () => {
    setEditedProject(project)
    setIsEditing(false)
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setEditedProject({ ...editedProject, [name]: value })
  }

  const calculateTotalAffectedArea = () => {
    return project.affectedRooms.reduce((total, room) => total + room.affectedFloorSF + room.affectedWallSF + room.affectedCeilingSF, 0)
  }

  if (loading) return <div>Loading...</div>
  if (error) return <div>Error: {error}</div>
  if (!project) return <div>Project not found</div>

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-6">{project.name}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Project Details</h2>
            {!isEditing ? (
              <button onClick={handleEdit} className="text-blue-500 hover:text-blue-700">
                <Edit className="w-5 h-5" />
              </button>
            ) : (
              <div>
                <button onClick={handleSave} className="text-green-500 hover:text-green-700 mr-2">
                  <Save className="w-5 h-5" />
                </button>
                <button onClick={handleCancel} className="text-red-500 hover:text-red-700">
                  <X className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
          {isEditing ? (
            <form>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Type</label>
                  <select
                    name="type"
                    value={editedProject.type}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  >
                    <option value="Water Mitigation">Water Mitigation</option>
                    <option value="Mold Remediation">Mold Remediation</option>
                    <option value="Fire Damage">Fire Damage</option>
                  </select>
                </div>
                {editedProject.type === 'Water Mitigation' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Category</label>
                    <select
                      name="category"
                      value={editedProject.category}
                      onChange={handleInputChange}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                    >
                      <option value="Category 1">Category 1 (Clean Water)</option>
                      <option value="Category 2">Category 2 (Gray Water)</option>
                      <option value="Category 3">Category 3 (Black Water)</option>
                    </select>
                  </div>
                )}
                <div>
                  <label className="block text-sm font-medium text-gray-700">Insurance Carrier</label>
                  <input
                    type="text"
                    name="insuranceCarrier"
                    value={editedProject.insuranceCarrier}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Claim Number</label>
                  <input
                    type="text"
                    name="claimNumber"
                    value={editedProject.claimNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Date of Loss</label>
                  <input
                    type="date"
                    name="dateOfLoss"
                    value={editedProject.dateOfLoss}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Status</label>
                  <select
                    name="status"
                    value={editedProject.status}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  >
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Street Address</label>
                  <input
                    type="text"
                    name="streetAddress"
                    value={editedProject.streetAddress}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">City</label>
                  <input
                    type="text"
                    name="city"
                    value={editedProject.city}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">State</label>
                  <input
                    type="text"
                    name="state"
                    value={editedProject.state}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Zip Code</label>
                  <input
                    type="text"
                    name="zipCode"
                    value={editedProject.zipCode}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Source of Loss</label>
                  <input
                    type="text"
                    name="sourceOfLoss"
                    value={editedProject.sourceOfLoss}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Completion Date</label>
                  <input
                    type="date"
                    name="completed"
                    value={editedProject.completed || ''}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </div>
              </div>
            </form>
          ) : (
            <div>
              <p><strong>Type:</strong> {project.type}</p>
              {project.type === 'Water Mitigation' && <p><strong>Category:</strong> {project.category}</p>}
              <p><strong>Insurance Carrier:</strong> {project.insuranceCarrier}</p>
              <p><strong>Claim Number:</strong> {project.claimNumber}</p>
              <p><strong>Date of Loss:</strong> {project.dateOfLoss}</p>
              <p><strong>Status:</strong> {project.status}</p>
              <p><strong>Address:</strong> {project.streetAddress}, {project.city}, {project.state} {project.zipCode}</p>
              <p><strong>Source of Loss:</strong> {project.sourceOfLoss}</p>
              <p><strong>Customer Called:</strong> {new Date(project.customerCalled.timestamp).toLocaleString()} by {project.customerCalled.user}</p>
              <p><strong>Site Inspected:</strong> {new Date(project.siteInspected.timestamp).toLocaleString()} by {project.siteInspected.user}</p>
              {project.completed && <p><strong>Date of Completion:</strong> {new Date(project.completed).toLocaleDateString()}</p>}
              <p><strong>Total Affected Area:</strong> {calculateTotalAffectedArea()} sq ft</p>
            </div>
          )}
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Project Notes</h2>
          <div className="mb-4">
            <textarea
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              className="w-full p-2 border rounded"
              placeholder="Add a new note..."
            />
            <button onClick={addNote} className="mt-2 bg-blue-500 text-white px-4 py-2 rounded">
              Add Note
            </button>
          </div>
          <ul className="space-y-4">
            {project.notes.map(note => (
              <li key={note.id} className="border-b pb-2">
                <p>{note.text}</p>
                <p className="text-sm text-gray-500">
                  {new Date(note.timestamp).toLocaleString()} by {note.user}
                </p>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Affected Rooms</h2>
          <ul className="space-y-4">
            {project.affectedRooms.map(room => (
              <li key={room.id} className="border-b pb-2">
                <p><strong>{room.name}</strong> (Floor Level: {room.floorLevel})</p>
                <p>Dimensions: {room.length}' x {room.width}' x {room.height}'</p>
                <p>Affected Areas:</p>
                <ul className="list-disc list-inside">
                  <li>Floor: {room.affectedFloorSF} sq ft</li>
                  <li>Wall: {room.affectedWallSF} sq ft</li>
                  <li>Ceiling: {room.affectedCeilingSF} sq ft</li>
                </ul>
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Equipment</h2>
          <ul className="space-y-4">
            {project.equipment.map(eq => (
              <li key={eq.id} className="border-b pb-2">
                <p><strong>{eq.type}</strong> - Model: {eq.model}</p>
                <p>Serial Number: {eq.serialNumber}</p>
                <p>Room: {project.affectedRooms.find(room => room.id === eq.roomId)?.name}</p>
                <p>Start Time: {new Date(eq.startTimestamp).toLocaleString()}</p>
                {eq.endTimestamp && <p>End Time: {new Date(eq.endTimestamp).toLocaleString()}</p>}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="mt-6 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Compliance Checks</h2>
        <ul className="space-y-4">
          {complianceChecks.map(check => (
            <li key={check.id} className="flex items-center">
              {check.status === 'Completed' ? (
                <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
              ) : (
                <AlertCircle className="w-5 h-5 text-yellow-500 mr-2" />
              )}
              <span>{check.description}</span>
              <span className={`ml-2 px-2 py-1 rounded text-xs ${
                check.status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
              }`}>
                {check.status}
              </span>
            </li>
          ))}
        </ul>
      </div>
      <div className="mt-6 flex space-x-4">
        <Link to={`/project/${project.id}/photos`} className="bg-green-500 text-white px-4 py-2 rounded flex items-center">
          <Camera className="w-5 h-5 mr-2" />
          Photos
        </Link>
        <Link to={`/project/${project.id}/documents`} className="bg-yellow-500 text-white px-4 py-2 rounded flex items-center">
          <FileText className="w-5 h-5 mr-2" />
          Documents
        </Link>
        <Link to={`/project/${project.id}/scope`} className="bg-purple-500 text-white px-4 py-2 rounded flex items-center">
          <Clipboard className="w-5 h-5 mr-2" />
          Scope of Work
        </Link>
        <Link to={`/project/${project.id}/equipment`} className="bg-blue-500 text-white px-4 py-2 rounded flex items-center">
          <Wrench className="w-5 h-5 mr-2" />
          Equipment
        </Link>
        <Link to={`/project/${project.id}/drying-details`} className="bg-indigo-500 text-white px-4 py-2 rounded flex items-center">
          <Droplet className="w-5 h-5 mr-2" />
          Drying Details
        </Link>
        <Link to={`/project/${project.id}/report-generator`} className="bg-red-500 text-white px-4 py-2 rounded flex items-center">
          <BarChart2 className="w-5 h-5 mr-2" />
          Generate Report
        </Link>
      </div>
    </div>
  )
}

export default ProjectDetail