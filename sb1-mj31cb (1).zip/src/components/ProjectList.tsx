import React, { useState } from 'react'
import { Plus, Edit, Trash, ChevronDown, ChevronUp, Camera } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useProjectContext } from '../contexts/ProjectContext'
import useFormValidation from '../hooks/useFormValidation'

const INITIAL_STATE = {
  name: '',
  type: 'Water Damage',
  status: 'In Progress',
}

const validate = (values) => {
  let errors = {}
  if (!values.name) {
    errors.name = 'Project name is required'
  }
  return errors
}

const ProjectList = () => {
  const { projects, loading, error, addProject, updateProject, deleteProject } = useProjectContext()
  const [expandedProject, setExpandedProject] = useState(null)
  const [showAddForm, setShowAddForm] = useState(false)

  const {
    handleChange,
    handleSubmit,
    values,
    errors,
    isSubmitting
  } = useFormValidation(INITIAL_STATE, validate)

  const handleAddProject = () => {
    addProject(values)
    setShowAddForm(false)
  }

  const handleEditProject = (project) => {
    // Implement edit functionality
    const updatedProject = { ...project, name: prompt('Enter new project name', project.name) }
    if (updatedProject.name) {
      updateProject(updatedProject)
    }
  }

  const handleDeleteProject = (id) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      deleteProject(id)
    }
  }

  const toggleProjectExpansion = (id) => {
    setExpandedProject(expandedProject === id ? null : id)
  }

  if (loading) return <div>Loading projects...</div>
  if (error) return <div>Error: {error}</div>

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Active Projects</h1>
      <button onClick={() => setShowAddForm(true)} className="mb-4 bg-blue-500 text-white px-4 py-2 rounded flex items-center">
        <Plus className="w-5 h-5 mr-2" />
        Add New Project
      </button>
      {showAddForm && (
        <form onSubmit={handleSubmit} className="mb-4 bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Add New Project</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <input
                type="text"
                name="name"
                placeholder="Project Name"
                value={values.name}
                onChange={handleChange}
                className={`border p-2 rounded w-full ${errors.name && 'border-red-500'}`}
              />
              {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
            </div>
            <select
              name="type"
              value={values.type}
              onChange={handleChange}
              className="border p-2 rounded"
            >
              <option value="Water Damage">Water Damage</option>
              <option value="Mold">Mold</option>
              <option value="Fire Damage">Fire Damage</option>
            </select>
          </div>
          <div className="mt-4 flex justify-end">
            <button type="button" onClick={() => setShowAddForm(false)} className="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              disabled={isSubmitting}
              onClick={handleAddProject}
            >
              {isSubmitting ? 'Adding...' : 'Add Project'}
            </button>
          </div>
        </form>
      )}
      <ul className="space-y-4">
        {projects.map(project => (
          <li key={project.id} className="bg-white p-4 rounded-lg shadow">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">{project.name}</h3>
              <div className="flex items-center space-x-2">
                <button onClick={() => handleEditProject(project)} className="text-blue-500">
                  <Edit className="w-5 h-5" />
                </button>
                <button onClick={() => handleDeleteProject(project.id)} className="text-red-500">
                  <Trash className="w-5 h-5" />
                </button>
                <button onClick={() => toggleProjectExpansion(project.id)} className="text-gray-500">
                  {expandedProject === project.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <p className="text-sm text-gray-500">Type: {project.type}</p>
            <p className="text-sm text-gray-500">Status: {project.status}</p>
            {expandedProject === project.id && (
              <div className="mt-4 space-y-4">
                <div className="flex space-x-4">
                  <Link to={`/project/${project.id}`} className="bg-blue-500 text-white px-4 py-2 rounded">
                    View Details
                  </Link>
                  <Link to={`/project/${project.id}/photos`} className="bg-green-500 text-white px-4 py-2 rounded flex items-center">
                    <Camera className="w-5 h-5 mr-2" />
                    Photos
                  </Link>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}

export default ProjectList