import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { Plus, Trash, Edit } from 'lucide-react'

const ProjectScope = () => {
  const { id } = useParams()
  const [project, setProject] = useState(null)
  const [showAddRoomForm, setShowAddRoomForm] = useState(false)
  const [showAddServiceForm, setShowAddServiceForm] = useState(false)
  const [selectedRoom, setSelectedRoom] = useState(null)
  const [newRoom, setNewRoom] = useState({
    name: '',
    floorLevel: '',
    length: '',
    width: '',
    height: '',
    offsets: '',
    affectedFloorSF: '',
    affectedWallSF: '',
    affectedCeilingSF: '',
  })
  const [newService, setNewService] = useState({
    description: '',
    quantity: '',
    unit: '',
    roomId: '',
  })

  useEffect(() => {
    // Fetch project details
    const fetchProjectDetails = async () => {
      // This is a placeholder for the API call
      const projectData = {
        id: parseInt(id),
        name: 'Water Damage Restoration - 123 Main St',
        affectedRooms: [
          {
            id: 1,
            name: 'Living Room',
            floorLevel: '1',
            length: '20',
            width: '15',
            height: '8',
            offsets: '2',
            affectedFloorSF: '300',
            affectedWallSF: '200',
            affectedCeilingSF: '300',
            services: [
              { id: 1, description: 'Water Extraction', quantity: '300', unit: 'SF' },
              { id: 2, description: 'Dehumidification', quantity: '24', unit: 'Hours' },
            ],
          },
          {
            id: 2,
            name: 'Kitchen',
            floorLevel: '1',
            length: '12',
            width: '10',
            height: '8',
            offsets: '0',
            affectedFloorSF: '120',
            affectedWallSF: '100',
            affectedCeilingSF: '120',
            services: [
              { id: 3, description: 'Tile Removal', quantity: '120', unit: 'SF' },
            ],
          },
        ],
      }
      setProject(projectData)
    }

    fetchProjectDetails()
  }, [id])

  const addRoom = () => {
    const roomToAdd = {
      ...newRoom,
      id: project.affectedRooms.length + 1,
      services: [],
    }
    setProject({
      ...project,
      affectedRooms: [...project.affectedRooms, roomToAdd],
    })
    setNewRoom({
      name: '',
      floorLevel: '',
      length: '',
      width: '',
      height: '',
      offsets: '',
      affectedFloorSF: '',
      affectedWallSF: '',
      affectedCeilingSF: '',
    })
    setShowAddRoomForm(false)
  }

  const editRoom = (room) => {
    setNewRoom(room)
    setShowAddRoomForm(true)
  }

  const updateRoom = () => {
    setProject({
      ...project,
      affectedRooms: project.affectedRooms.map(room =>
        room.id === newRoom.id ? newRoom : room
      ),
    })
    setNewRoom({
      name: '',
      floorLevel: '',
      length: '',
      width: '',
      height: '',
      offsets: '',
      affectedFloorSF: '',
      affectedWallSF: '',
      affectedCeilingSF: '',
    })
    setShowAddRoomForm(false)
  }

  const deleteRoom = (id) => {
    setProject({
      ...project,
      affectedRooms: project.affectedRooms.filter(room => room.id !== id),
    })
  }

  const addService = () => {
    const serviceToAdd = {
      ...newService,
      id: selectedRoom.services.length + 1,
    }
    setProject({
      ...project,
      affectedRooms: project.affectedRooms.map(room =>
        room.id === parseInt(newService.roomId)
          ? { ...room, services: [...room.services, serviceToAdd] }
          : room
      ),
    })
    setNewService({
      description: '',
      quantity: '',
      unit: '',
      roomId: '',
    })
    setShowAddServiceForm(false)
  }

  const editService = (service, roomId) => {
    setNewService({ ...service, roomId: roomId.toString() })
    setShowAddServiceForm(true)
  }

  const updateService = () => {
    setProject({
      ...project,
      affectedRooms: project.affectedRooms.map(room =>
        room.id === parseInt(newService.roomId)
          ? {
              ...room,
              services: room.services.map(service =>
                service.id === newService.id ? newService : service
              ),
            }
          : room
      ),
    })
    setNewService({
      description: '',
      quantity: '',
      unit: '',
      roomId: '',
    })
    setShowAddServiceForm(false)
  }

  const deleteService = (serviceId, roomId) => {
    setProject({
      ...project,
      affectedRooms: project.affectedRooms.map(room =>
        room.id === roomId
          ? { ...room, services: room.services.filter(service => service.id !== serviceId) }
          : room
      ),
    })
  }

  if (!project) {
    return <div>Loading...</div>
  }

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-6">Project Scope: {project.name}</h1>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Affected Rooms</h2>
        <button
          onClick={() => setShowAddRoomForm(true)}
          className="mb-4 bg-blue-500 text-white px-4 py-2 rounded flex items-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Room
        </button>
        {showAddRoomForm && (
          <form onSubmit={(e) => { e.preventDefault(); newRoom.id ? updateRoom() : addRoom(); }} className="mb-4 bg-white p-4 rounded-lg shadow">
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Room Name"
                value={newRoom.name}
                onChange={(e) => setNewRoom({ ...newRoom, name: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Floor Level"
                value={newRoom.floorLevel}
                onChange={(e) => setNewRoom({ ...newRoom, floorLevel: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Length"
                value={newRoom.length}
                onChange={(e) => setNewRoom({ ...newRoom, length: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Width"
                value={newRoom.width}
                onChange={(e) => setNewRoom({ ...newRoom, width: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Height"
                value={newRoom.height}
                onChange={(e) => setNewRoom({ ...newRoom, height: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Offsets greater than 18"
                value={newRoom.offsets}
                onChange={(e) => setNewRoom({ ...newRoom, offsets: e.target.value })}
                className="border p-2 rounded"
              />
              <input
                type="number"
                placeholder="Affected Floor SF"
                value={newRoom.affectedFloorSF}
                onChange={(e) => setNewRoom({ ...newRoom, affectedFloorSF: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Affected Wall SF"
                value={newRoom.affectedWallSF}
                onChange={(e) => setNewRoom({ ...newRoom, affectedWallSF: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Affected Ceiling SF"
                value={newRoom.affectedCeilingSF}
                onChange={(e) => setNewRoom({ ...newRoom, affectedCeilingSF: e.target.value })}
                className="border p-2 rounded"
                required
              />
            </div>
            <button type="submit" className="mt-4 bg-green-500 text-white px-4 py-2 rounded">
              {newRoom.id ? 'Update Room' : 'Add Room'}
            </button>
          </form>
        )}
        <ul className="space-y-4">
          {project.affectedRooms.map(room => (
            <li key={room.id} className="bg-white p-4 rounded-lg shadow">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">{room.name}</h3>
                <div>
                  <button onClick={() => editRoom(room)} className="text-blue-500 mr-2">
                    <Edit className="w-5 h-5" />
                  </button>
                  <button onClick={() => deleteRoom(room.id)} className="text-red-500">
                    <Trash className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <p>Floor Level: {room.floorLevel}</p>
              <p>Dimensions: {room.length}' x {room.width}' x {room.height}'</p>
              <p>Offsets greater than 18": {room.offsets}</p>
              <p>Affected Floor: {room.affectedFloorSF} SF</p>
              <p>Affected Wall: {room.affectedWallSF} SF</p>
              <p>Affected Ceiling: {room.affectedCeilingSF} SF</p>
              
              <div className="mt-4">
                <h4 className="font-semibold">Services</h4>
                <ul className="list-disc pl-5">
                  {room.services.map(service => (
                    <li key={service.id} className="flex justify-between items-center">
                      <span>{service.description} - {service.quantity} {service.unit}</span>
                      <div>
                        <button onClick={() => editService(service, room.id)} className="text-blue-500 mr-2">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteService(service.id, room.id)} className="text-red-500">
                          <Trash className="w-4 h-4" />
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => {
                    setSelectedRoom(room)
                    setShowAddServiceForm(true)
                    setNewService({ ...newService, roomId: room.id.toString() })
                  }}
                  className="mt-2 bg-green-500 text-white px-3 py-1 rounded text-sm flex items-center"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Service
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {showAddServiceForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full" id="my-modal">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3 text-center">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Add Service</h3>
              <form onSubmit={(e) => { e.preventDefault(); newService.id ? updateService() : addService(); }} className="mt-2">
                <input
                  type="text"
                  placeholder="Service Description"
                  value={newService.description}
                  onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                  className="mt-2 p-2 w-full border rounded"
                  required
                />
                <input
                  type="number"
                  placeholder="Quantity"
                  value={newService.quantity}
                  onChange={(e) => setNewService({ ...newService, quantity: e.target.value })}
                  className="mt-2 p-2 w-full border rounded"
                  required
                />
                <input
                  type="text"
                  placeholder="Unit"
                  value={newService.unit}
                  onChange={(e) => setNewService({ ...newService, unit: e.target.value })}
                  className="mt-2 p-2 w-full border rounded"
                  required
                />
                <select
                  value={newService.roomId}
                  onChange={(e) => setNewService({ ...newService, roomId: e.target.value })}
                  className="mt-2 p-2 w-full border rounded"
                  required
                >
                  <option value="">Select Room</option>
                  {project.affectedRooms.map(room => (
                    <option key={room.id} value={room.id}>{room.name}</option>
                  ))}
                </select>
                <div className="items-center px-4 py-3">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-500 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300"
                  >
                    {newService.id ? 'Update Service' : 'Add Service'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ProjectScope