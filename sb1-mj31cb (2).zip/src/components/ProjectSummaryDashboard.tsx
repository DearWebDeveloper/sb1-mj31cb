import React from 'react'
import { useParams } from 'react-router-dom'
import { useProjectContext } from '../contexts/ProjectContext'
import { BarChart2, Clock, Droplet, Thermometer } from 'lucide-react'
import { Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

const ProjectSummaryDashboard = () => {
  const { id } = useParams()
  const { projects } = useProjectContext()
  const project = projects.find(p => p.id === parseInt(id))

  if (!project) return <div>Loading...</div>

  const moistureData = {
    labels: project.moistureReadings.map(reading => reading.date),
    datasets: [
      {
        label: 'Average Moisture Content',
        data: project.moistureReadings.map(reading => 
          reading.chamberReadings.reduce((sum, cr) => sum + cr.humidity, 0) / reading.chamberReadings.length
        ),
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }
    ]
  }

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Moisture Trend',
      },
    },
  }

  const calculateProjectDuration = () => {
    const start = new Date(project.createdAt)
    const end = project.completedAt ? new Date(project.completedAt) : new Date()
    const diffTime = Math.abs(end - start)
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  }

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-4 flex items-center">
        <BarChart2 className="w-6 h-6 mr-2" />
        Project Summary Dashboard
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-blue-100 p-4 rounded-md">
          <h3 className="text-lg font-semibold mb-2 flex items-center">
            <Clock className="w-5 h-5 mr-2" />
            Project Duration
          </h3>
          <p className="text-2xl font-bold">{calculateProjectDuration()} days</p>
        </div>
        <div className="bg-green-100 p-4 rounded-md">
          <h3 className="text-lg font-semibold mb-2 flex items-center">
            <Droplet className="w-5 h-5 mr-2" />
            Affected Area
          </h3>
          <p className="text-2xl font-bold">
            {project.affectedRooms.reduce((sum, room) => sum + parseFloat(room.affectedFloorSF), 0).toFixed(2)} sq ft
          </p>
        </div>
        <div className="bg-yellow-100 p-4 rounded-md">
          <h3 className="text-lg font-semibold mb-2 flex items-center">
            <Thermometer className="w-5 h-5 mr-2" />
            Avg. Temperature
          </h3>
          <p className="text-2xl font-bold">
            {project.moistureReadings.length > 0
              ? (project.moistureReadings.reduce((sum, reading) => 
                  sum + reading.chamberReadings.reduce((chamberSum, cr) => chamberSum + cr.temperature, 0) / reading.chamberReadings.length
                , 0) / project.moistureReadings.length).toFixed(1)
              : 'N/A'} °F
          </p>
        </div>
        <div className="bg-purple-100 p-4 rounded-md">
          <h3 className="text-lg font-semibold mb-2 flex items-center">
            <Wrench className="w-5 h-5 mr-2" />
            Equipment Used
          </h3>
          <p className="text-2xl font-bold">
            {project.dryingChambers.reduce((sum, chamber) => sum + chamber.equipment.length, 0)}
          </p>
        </div>
      </div>
      <div className="mt-6">
        <Line options={options} data={moistureData} />
      </div>
    </div>
  )
}

export default ProjectSummaryDashboard