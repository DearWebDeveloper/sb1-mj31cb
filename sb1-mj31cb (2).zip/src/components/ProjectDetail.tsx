import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Camera, FileText, Clipboard, Wrench, BarChart2, Droplet, Edit, Save, X, AlertCircle, CheckCircle, Calendar, Trash2, MessageSquare } from 'lucide-react'
import { useProjectContext } from '../contexts/ProjectContext'
import { useRole } from '../contexts/RoleContext'
import ProjectTimeline from './ProjectTimeline'
import ProjectNotes from './ProjectNotes'
import ProjectSummaryDashboard from './ProjectSummaryDashboard'
import ProjectTasks from './ProjectTasks'

const ProjectDetail = () => {
  // ... existing code ...

  return (
    <div className="p-4">
      {/* ... existing JSX ... */}
      
      <div className="mt-8">
        <ProjectSummaryDashboard />
      </div>

      <div className="mt-8">
        <ProjectTimeline />
      </div>

      <div className="mt-8">
        <ProjectNotes />
      </div>

      <div className="mt-8">
        <ProjectTasks />
      </div>

      {/* ... rest of the component ... */}
    </div>
  )
}

export default ProjectDetail