import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Camera, FileText, Clipboard, Wrench, BarChart2, Droplet, Edit, Save, X, AlertCircle, CheckCircle, Calendar } from 'lucide-react'
import { useProjectContext } from '../contexts/ProjectContext'
import { useRole } from '../contexts/RoleContext'

// ... rest of the component remains the same

const ProjectDetail = () => {
  // ... existing code

  return (
    <div className="p-4">
      {/* ... other JSX */}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {/* ... other links */}
        <Link to={`/project/${project.id}/equipment`} className="bg-blue-500 text-white px-4 py-2 rounded flex items-center justify-center">
          <Wrench className="w-5 h-5 mr-2" />
          Equipment
        </Link>
        {/* ... other links */}
      </div>

      {/* ... rest of the JSX */}
    </div>
  )
}

export default ProjectDetail