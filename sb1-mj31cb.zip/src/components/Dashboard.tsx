import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Droplet, CheckSquare, Box, MessageCircle } from 'lucide-react'

const Dashboard = () => {
  const navigate = useNavigate()

  const dashboardItems = [
    { title: "Active Projects", value: "5", icon: Droplet, color: "text-blue-500", route: "/projects" },
    { title: "Compliance Tasks", value: "12", icon: CheckSquare, color: "text-green-500", route: "/compliance" },
    { title: "Equipment Stock", value: "25 units", icon: Box, color: "text-yellow-500", route: "/equipment" },
    { title: "Homeowner Messages", value: "3", icon: MessageCircle, color: "text-purple-500", route: "/messages" },
  ]

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {dashboardItems.map((item, index) => (
          <DashboardCard
            key={index}
            title={item.title}
            value={item.value}
            icon={item.icon}
            color={item.color}
            onClick={() => navigate(item.route)}
          />
        ))}
      </div>
    </div>
  )
}

const DashboardCard = ({ title, value, icon: Icon, color, onClick }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow duration-300" onClick={onClick}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-500 text-sm">{title}</p>
          <p className="text-2xl font-semibold mt-1">{value}</p>
        </div>
        <Icon className={`w-12 h-12 ${color}`} />
      </div>
    </div>
  )
}

export default Dashboard