import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Plus, Edit, Trash, Camera, FileText, Clipboard, Wrench } from 'lucide-react'

// ... (rest of the file remains unchanged)

const ProjectDetail = () => {
  // ... (existing code)

  return (
    <div className="p-4">
      {/* ... (existing JSX) */}
      <div className="mt-6 flex space-x-4">
        <Link to={`/project/${project.id}/photos`} className="bg-green-500 text-white px-4 py-2 rounded flex items-center">
          <Camera className="w-5 h-5 mr-2" />
          Photos
        </Link>
        <Link to={`/project/${project.id}/documents`} className="bg-yellow-500 text-white px-4 py-2 rounded flex items-center">
          <FileText className="w-5 h-5 mr-2" />
          Documents
        </Link>
        <Link to={`/project/${project.id}/scope`} className="bg-purple-500 text-white px-4 py-2 rounded flex items-center">
          <Clipboard className="w-5 h-5 mr-2" />
          Scope of Work
        </Link>
        <Link to={`/project/${project.id}/equipment`} className="bg-blue-500 text-white px-4 py-2 rounded flex items-center">
          <Wrench className="w-5 h-5 mr-2" />
          Equipment
        </Link>
      </div>
    </div>
  )
}

export default ProjectDetail