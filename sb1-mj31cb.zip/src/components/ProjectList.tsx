import React, { useState } from 'react'
import { Plus, Edit, Trash, ChevronDown, ChevronUp, Camera } from 'lucide-react'
import { Link } from 'react-router-dom'

const ProjectList = () => {
  const [projects, setProjects] = useState([
    {
      id: 1,
      name: 'Water Damage Restoration - 123 Main St',
      type: 'Water Damage',
      category: 'Flood',
      insuranceCarrier: 'ABC Insurance',
      claimNumber: 'WD12345',
      dateOfLoss: '2023-04-01',
      status: 'In Progress',
      streetAddress: '123 Main St',
      city: 'Anytown',
      state: 'CA',
      zipCode: '12345',
      sourceOfLoss: 'Pipe Burst',
      customerCalled: { timestamp: '2023-04-01T08:00:00Z', user: 'john@example.com' },
      siteInspected: { timestamp: '2023-04-01T10:00:00Z', user: 'jane@example.com' },
      completed: null,
      affectedRooms: [],
      notes: [],
      photos: [],
    },
  ])

  const [expandedProject, setExpandedProject] = useState(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [showEditForm, setShowEditForm] = useState(false)
  const [editingProject, setEditingProject] = useState(null)
  const [newProject, setNewProject] = useState({
    name: '',
    type: 'Water Damage',
    category: '',
    insuranceCarrier: '',
    claimNumber: '',
    dateOfLoss: '',
    streetAddress: '',
    city: '',
    state: '',
    zipCode: '',
    sourceOfLoss: '',
    customerCalled: null,
    siteInspected: null,
    completed: null,
  })

  const projectTypes = ['Water Damage', 'Mold Remediation', 'Fire Cleanup', 'Contents', 'Repair']
  const waterDamageCategories = ['Flood', 'Roof Leak', 'Pipe Burst', 'Sewage Backup', 'Other']
  const states = ['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA', 'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY']

  const addProject = () => {
    setShowAddForm(true)
  }

  const handleAddProject = (e) => {
    e.preventDefault()
    const projectToAdd = {
      ...newProject,
      id: projects.length + 1,
      status: 'In Progress',
      customerCalled: { timestamp: new Date().toISOString(), user: 'currentUser@example.com' },
      affectedRooms: [],
      notes: [],
      photos: [],
    }
    setProjects(prevProjects => [...prevProjects, projectToAdd])
    setShowAddForm(false)
    setNewProject({
      name: '',
      type: 'Water Damage',
      category: '',
      insuranceCarrier: '',
      claimNumber: '',
      dateOfLoss: '',
      streetAddress: '',
      city: '',
      state: '',
      zipCode: '',
      sourceOfLoss: '',
      customerCalled: null,
      siteInspected: null,
      completed: null,
    })
  }

  const editProject = (id) => {
    const projectToEdit = projects.find(project => project.id === id)
    setEditingProject(projectToEdit)
    setShowEditForm(true)
  }

  const handleEditProject = (e) => {
    e.preventDefault()
    setProjects(projects.map(project => 
      project.id === editingProject.id ? {
        ...editingProject,
        status: editingProject.completed ? 'Completed' : 'In Progress'
      } : project
    ))
    setShowEditForm(false)
    setEditingProject(null)
  }

  const deleteProject = (id) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      setProjects(projects.filter(project => project.id !== id))
    }
  }

  const toggleProjectExpansion = (id) => {
    setExpandedProject(expandedProject === id ? null : id)
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Active Projects</h1>
      <button onClick={addProject} className="mb-4 bg-blue-500 text-white px-4 py-2 rounded flex items-center">
        <Plus className="w-5 h-5 mr-2" />
        Add New Project
      </button>
      {showAddForm && (
        <form onSubmit={handleAddProject} className="mb-4 bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Add New Project</h2>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Project Name"
              value={newProject.name}
              onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <select
              value={newProject.type}
              onChange={(e) => setNewProject({ ...newProject, type: e.target.value })}
              className="border p-2 rounded"
              required
            >
              {projectTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
            {newProject.type === 'Water Damage' && (
              <select
                value={newProject.category}
                onChange={(e) => setNewProject({ ...newProject, category: e.target.value })}
                className="border p-2 rounded"
                required
              >
                <option value="">Select Category</option>
                {waterDamageCategories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            )}
            <input
              type="text"
              placeholder="Insurance Carrier"
              value={newProject.insuranceCarrier}
              onChange={(e) => setNewProject({ ...newProject, insuranceCarrier: e.target.value })}
              className="border p-2 rounded"
            />
            <input
              type="text"
              placeholder="Claim Number"
              value={newProject.claimNumber}
              onChange={(e) => setNewProject({ ...newProject, claimNumber: e.target.value })}
              className="border p-2 rounded"
            />
            <input
              type="date"
              placeholder="Date of Loss"
              value={newProject.dateOfLoss}
              onChange={(e) => setNewProject({ ...newProject, dateOfLoss: e.target.value })}
              className="border p-2 rounded"
            />
            <input
              type="text"
              placeholder="Street Address"
              value={newProject.streetAddress}
              onChange={(e) => setNewProject({ ...newProject, streetAddress: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <input
              type="text"
              placeholder="City"
              value={newProject.city}
              onChange={(e) => setNewProject({ ...newProject, city: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <select
              value={newProject.state}
              onChange={(e) => setNewProject({ ...newProject, state: e.target.value })}
              className="border p-2 rounded"
              required
            >
              <option value="">Select State</option>
              {states.map(state => (
                <option key={state} value={state}>{state}</option>
              ))}
            </select>
            <input
              type="text"
              placeholder="Zip Code"
              value={newProject.zipCode}
              onChange={(e) => setNewProject({ ...newProject, zipCode: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <input
              type="text"
              placeholder="Source of Loss"
              value={newProject.sourceOfLoss}
              onChange={(e) => setNewProject({ ...newProject, sourceOfLoss: e.target.value })}
              className="border p-2 rounded"
            />
          </div>
          <div className="mt-4 flex justify-end">
            <button type="button" onClick={() => setShowAddForm(false)} className="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
              Add Project
            </button>
          </div>
        </form>
      )}
      {showEditForm && (
        <form onSubmit={handleEditProject} className="mb-4 bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Edit Project</h2>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Project Name"
              value={editingProject.name}
              onChange={(e) => setEditingProject({ ...editingProject, name: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <select
              value={editingProject.type}
              onChange={(e) => setEditingProject({ ...editingProject, type: e.target.value })}
              className="border p-2 rounded"
              required
            >
              {projectTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
            {editingProject.type === 'Water Damage' && (
              <select
                value={editingProject.category}
                onChange={(e) => setEditingProject({ ...editingProject, category: e.target.value })}
                className="border p-2 rounded"
                required
              >
                <option value="">Select Category</option>
                {waterDamageCategories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            )}
            <input
              type="text"
              placeholder="Insurance Carrier"
              value={editingProject.insuranceCarrier}
              onChange={(e) => setEditingProject({ ...editingProject, insuranceCarrier: e.target.value })}
              className="border p-2 rounded"
            />
            <input
              type="text"
              placeholder="Claim Number"
              value={editingProject.claimNumber}
              onChange={(e) => setEditingProject({ ...editingProject, claimNumber: e.target.value })}
              className="border p-2 rounded"
            />
            <input
              type="date"
              placeholder="Date of Loss"
              value={editingProject.dateOfLoss}
              onChange={(e) => setEditingProject({ ...editingProject, dateOfLoss: e.target.value })}
              className="border p-2 rounded"
            />
            <input
              type="text"
              placeholder="Street Address"
              value={editingProject.streetAddress}
              onChange={(e) => setEditingProject({ ...editingProject, streetAddress: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <input
              type="text"
              placeholder="City"
              value={editingProject.city}
              onChange={(e) => setEditingProject({ ...editingProject, city: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <select
              value={editingProject.state}
              onChange={(e) => setEditingProject({ ...editingProject, state: e.target.value })}
              className="border p-2 rounded"
              required
            >
              <option value="">Select State</option>
              {states.map(state => (
                <option key={state} value={state}>{state}</option>
              ))}
            </select>
            <input
              type="text"
              placeholder="Zip Code"
              value={editingProject.zipCode}
              onChange={(e) => setEditingProject({ ...editingProject, zipCode: e.target.value })}
              className="border p-2 rounded"
              required
            />
            <input
              type="text"
              placeholder="Source of Loss"
              value={editingProject.sourceOfLoss}
              onChange={(e) => setEditingProject({ ...editingProject, sourceOfLoss: e.target.value })}
              className="border p-2 rounded"
            />
            <input
              type="date"
              placeholder="Date of Completion"
              value={editingProject.completed}
              onChange={(e) => setEditingProject({ ...editingProject, completed: e.target.value })}
              className="border p-2 rounded"
            />
          </div>
          <div className="mt-4 flex justify-end">
            <button type="button" onClick={() => setShowEditForm(false)} className="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
              Save Changes
            </button>
          </div>
        </form>
      )}
      <ul className="space-y-4">
        {projects.map(project => (
          <li key={project.id} className="bg-white p-4 rounded-lg shadow">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">{project.name}</h3>
              <div className="flex items-center space-x-2">
                <button onClick={() => editProject(project.id)} className="text-blue-500">
                  <Edit className="w-5 h-5" />
                </button>
                <button onClick={() => deleteProject(project.id)} className="text-red-500">
                  <Trash className="w-5 h-5" />
                </button>
                <button onClick={() => toggleProjectExpansion(project.id)} className="text-gray-500">
                  {expandedProject === project.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <p className="text-sm text-gray-500">Type: {project.type}</p>
            <p className="text-sm text-gray-500">Status: {project.status}</p>
            {expandedProject === project.id && (
              <div className="mt-4 space-y-4">
                <div>
                  <h4 className="font-semibold">Project Details</h4>
                  <p>Category: {project.category}</p>
                  <p>Insurance Carrier: {project.insuranceCarrier}</p>
                  <p>Claim Number: {project.claimNumber}</p>
                  <p>Date of Loss: {project.dateOfLoss}</p>
                  <p>Address: {project.streetAddress}, {project.city}, {project.state} {project.zipCode}</p>
                  <p>Source of Loss: {project.sourceOfLoss}</p>
                  <p>Customer Called: {new Date(project.customerCalled.timestamp).toLocaleString()}</p>
                  <p>Site Inspected: {new Date(project.siteInspected.timestamp).toLocaleString()}</p>
                  {project.completed && <p>Date of Completion: {new Date(project.completed).toLocaleDateString()}</p>}
                </div>
                <div className="flex space-x-4">
                  <Link to={`/project/${project.id}`} className="bg-blue-500 text-white px-4 py-2 rounded">
                    View Details
                  </Link>
                  <Link to={`/project/${project.id}/photos`} className="bg-green-500 text-white px-4 py-2 rounded flex items-center">
                    <Camera className="w-5 h-5 mr-2" />
                    Photos
                  </Link>
                  <Link to={`/project/${project.id}/documents`} className="bg-yellow-500 text-white px-4 py-2 rounded">
                    Documents
                  </Link>
                  <Link to={`/project/${project.id}/scope`} className="bg-purple-500 text-white px-4 py-2 rounded">
                    Scope of Work
                  </Link>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}

export default ProjectList