import React, { useState, useEffect } from 'react'
import { Plus, Trash, Edit } from 'lucide-react'
import { useParams } from 'react-router-dom'

const EquipmentDryingDetails = () => {
  const { id: projectId } = useParams()
  const [project, setProject] = useState(null)
  const [dryingReport, setDryingReport] = useState({
    timestamp: new Date().toISOString(),
    dryingChambers: [],
  })
  const [availableEquipment, setAvailableEquipment] = useState([])

  useEffect(() => {
    // Fetch project details and available equipment
    const fetchProjectDetails = async () => {
      // Simulated API call
      const projectData = {
        id: projectId,
        name: 'Water Damage Restoration - 123 Main St',
        affectedRooms: [
          { id: 1, name: 'Living Room' },
          { id: 2, name: 'Kitchen' },
        ],
      }
      setProject(projectData)
    }

    const fetchAvailableEquipment = async () => {
      // Simulated API call
      const equipmentData = [
        { id: 1, type: 'Dehumidifier', model: 'DH-2000' },
        { id: 2, type: 'Air Mover', model: 'AM-500' },
      ]
      setAvailableEquipment(equipmentData)
    }

    fetchProjectDetails()
    fetchAvailableEquipment()
  }, [projectId])

  const addChamber = () => {
    const newChamber = {
      id: Date.now(), // Use timestamp as a unique id
      name: `Chamber ${dryingReport.dryingChambers.length + 1}`,
      rooms: [],
      equipment: [],
      dailyReadings: [],
    }
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: [...prevReport.dryingChambers, newChamber],
    }))
  }

  const editChamber = (chamberId, newName) => {
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: prevReport.dryingChambers.map(chamber =>
        chamber.id === chamberId ? { ...chamber, name: newName } : chamber
      ),
    }))
  }

  const deleteChamber = (chamberId) => {
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: prevReport.dryingChambers.filter(chamber => chamber.id !== chamberId),
    }))
  }

  const addRoomToChamber = (chamberId, roomId) => {
    if (!project) return
    const room = project.affectedRooms.find(r => r.id === parseInt(roomId))
    if (!room) return
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: prevReport.dryingChambers.map(chamber =>
        chamber.id === chamberId ? { ...chamber, rooms: [...chamber.rooms, room] } : chamber
      ),
    }))
  }

  const addEquipmentToChamber = (chamberId, equipmentId) => {
    const equipment = availableEquipment.find(e => e.id === parseInt(equipmentId))
    if (!equipment) return
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: prevReport.dryingChambers.map(chamber =>
        chamber.id === chamberId ? {
          ...chamber,
          equipment: [...chamber.equipment, { ...equipment, setTimestamp: new Date().toISOString() }]
        } : chamber
      ),
    }))
  }

  const addDailyReading = (chamberId) => {
    const chamber = dryingReport.dryingChambers.find(c => c.id === chamberId)
    if (!chamber) return

    const newReading = {
      id: Date.now(), // Use timestamp as a unique id
      date: new Date().toISOString().split('T')[0],
      outsideConditions: { temperature: '', RH: '', GPP: '' },
      unaffectedAreaConditions: { temperature: '', RH: '', GPP: '' },
      rooms: chamber.rooms.map(room => ({
        id: room.id,
        name: room.name,
        temperature: '',
        RH: '',
        GPP: '',
        materials: [],
      })),
      equipment: chamber.equipment.map(eq => ({
        id: eq.id,
        type: eq.type,
        model: eq.model,
        temperature: '',
        RH: '',
        GPP: '',
        GDEP: '',
        runtimeHours: '',
      })),
    }
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: prevReport.dryingChambers.map(c =>
        c.id === chamberId ? { ...c, dailyReadings: [...c.dailyReadings, newReading] } : c
      ),
    }))
  }

  const updateDailyReading = (chamberId, readingId, updatedReading) => {
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: prevReport.dryingChambers.map(chamber =>
        chamber.id === chamberId ? {
          ...chamber,
          dailyReadings: chamber.dailyReadings.map(reading =>
            reading.id === readingId ? updatedReading : reading
          )
        } : chamber
      ),
    }))
  }

  const addMaterialToRoom = (chamberId, readingId, roomId, material) => {
    setDryingReport(prevReport => ({
      ...prevReport,
      dryingChambers: prevReport.dryingChambers.map(chamber =>
        chamber.id === chamberId ? {
          ...chamber,
          dailyReadings: chamber.dailyReadings.map(reading =>
            reading.id === readingId ? {
              ...reading,
              rooms: reading.rooms.map(room =>
                room.id === roomId ? {
                  ...room,
                  materials: [...room.materials, material]
                } : room
              )
            } : reading
          )
        } : chamber
      ),
    }))
  }

  if (!project) {
    return <div>Loading...</div>
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Equipment & Drying Details</h1>
      <p className="mb-4">Project: {project.name}</p>
      <button onClick={addChamber} className="mb-4 bg-blue-500 text-white px-4 py-2 rounded flex items-center">
        <Plus className="w-5 h-5 mr-2" />
        Add Drying Chamber
      </button>
      {dryingReport.dryingChambers.map(chamber => (
        <div key={chamber.id} className="mb-8 bg-white p-4 rounded-lg shadow">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-semibold">{chamber.name}</h2>
            <div>
              <button onClick={() => editChamber(chamber.id, prompt('Enter new chamber name:'))} className="text-blue-500 mr-2">
                <Edit className="w-5 h-5" />
              </button>
              <button onClick={() => deleteChamber(chamber.id)} className="text-red-500">
                <Trash className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="mb-4">
            <h3 className="text-xl font-semibold mb-2">Rooms</h3>
            <select
              onChange={(e) => addRoomToChamber(chamber.id, e.target.value)}
              className="border p-2 rounded"
            >
              <option value="">Add room to chamber</option>
              {project.affectedRooms.map(room => (
                <option key={room.id} value={room.id}>{room.name}</option>
              ))}
            </select>
            <ul className="list-disc pl-5 mt-2">
              {chamber.rooms.map(room => (
                <li key={room.id}>{room.name}</li>
              ))}
            </ul>
          </div>
          <div className="mb-4">
            <h3 className="text-xl font-semibold mb-2">Equipment</h3>
            <select
              onChange={(e) => addEquipmentToChamber(chamber.id, e.target.value)}
              className="border p-2 rounded"
            >
              <option value="">Add equipment to chamber</option>
              {availableEquipment.map(equipment => (
                <option key={equipment.id} value={equipment.id}>{equipment.type} - {equipment.model}</option>
              ))}
            </select>
            <ul className="list-disc pl-5 mt-2">
              {chamber.equipment.map(eq => (
                <li key={eq.id}>{eq.type} - {eq.model} (Set: {new Date(eq.setTimestamp).toLocaleString()})</li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Daily Readings</h3>
            {chamber.dailyReadings.map((reading) => (
              <div key={reading.id} className="mb-4 p-3 bg-gray-100 rounded">
                <p className="font-semibold">Date: {reading.date}</p>
                {/* Add forms for updating daily readings */}
              </div>
            ))}
            <button onClick={() => addDailyReading(chamber.id)} className="mt-2 bg-green-500 text-white px-3 py-1 rounded text-sm">
              Add Daily Reading
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}

export default EquipmentDryingDetails