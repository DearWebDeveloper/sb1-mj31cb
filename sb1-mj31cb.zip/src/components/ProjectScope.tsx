import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { Plus, Trash, Edit } from 'lucide-react'

const ProjectScope = () => {
  const { id } = useParams()
  const [project, setProject] = useState(null)
  const [showAddRoomForm, setShowAddRoomForm] = useState(false)
  const [showAddServiceForm, setShowAddServiceForm] = useState(false)
  const [newRoom, setNewRoom] = useState({
    name: '',
    floorLevel: '',
    length: '',
    width: '',
    height: '',
    offsets: '',
    affectedFloorSF: '',
    affectedWallSF: '',
    affectedCeilingSF: '',
  })
  const [newService, setNewService] = useState({
    description: '',
    quantity: '',
    unit: '',
  })
  const [editingRoomId, setEditingRoomId] = useState(null)
  const [editingServiceId, setEditingServiceId] = useState(null)

  useEffect(() => {
    // Fetch project details
    // This is a placeholder for the API call
    const fetchProjectDetails = async () => {
      // Simulated API call
      const projectData = {
        id: parseInt(id),
        name: 'Water Damage Restoration - 123 Main St',
        affectedRooms: [
          {
            id: 1,
            name: 'Living Room',
            floorLevel: '1',
            length: '20',
            width: '15',
            height: '8',
            offsets: '2',
            affectedFloorSF: '300',
            affectedWallSF: '200',
            affectedCeilingSF: '300',
          },
        ],
        services: [
          {
            id: 1,
            description: 'Water Extraction',
            quantity: '300',
            unit: 'SF',
          },
        ],
      }
      setProject(projectData)
    }

    fetchProjectDetails()
  }, [id])

  const addRoom = () => {
    const roomToAdd = {
      ...newRoom,
      id: project.affectedRooms.length + 1,
    }
    setProject({
      ...project,
      affectedRooms: [...project.affectedRooms, roomToAdd],
    })
    setNewRoom({
      name: '',
      floorLevel: '',
      length: '',
      width: '',
      height: '',
      offsets: '',
      affectedFloorSF: '',
      affectedWallSF: '',
      affectedCeilingSF: '',
    })
    setShowAddRoomForm(false)
  }

  const editRoom = (room) => {
    setEditingRoomId(room.id)
    setNewRoom(room)
  }

  const updateRoom = () => {
    setProject({
      ...project,
      affectedRooms: project.affectedRooms.map(room =>
        room.id === editingRoomId ? newRoom : room
      ),
    })
    setEditingRoomId(null)
    setNewRoom({
      name: '',
      floorLevel: '',
      length: '',
      width: '',
      height: '',
      offsets: '',
      affectedFloorSF: '',
      affectedWallSF: '',
      affectedCeilingSF: '',
    })
  }

  const deleteRoom = (id) => {
    setProject({
      ...project,
      affectedRooms: project.affectedRooms.filter(room => room.id !== id),
    })
  }

  const addService = () => {
    const serviceToAdd = {
      ...newService,
      id: project.services.length + 1,
    }
    setProject({
      ...project,
      services: [...project.services, serviceToAdd],
    })
    setNewService({
      description: '',
      quantity: '',
      unit: '',
    })
    setShowAddServiceForm(false)
  }

  const editService = (service) => {
    setEditingServiceId(service.id)
    setNewService(service)
  }

  const updateService = () => {
    setProject({
      ...project,
      services: project.services.map(service =>
        service.id === editingServiceId ? newService : service
      ),
    })
    setEditingServiceId(null)
    setNewService({
      description: '',
      quantity: '',
      unit: '',
    })
  }

  const deleteService = (id) => {
    setProject({
      ...project,
      services: project.services.filter(service => service.id !== id),
    })
  }

  if (!project) {
    return <div>Loading...</div>
  }

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-6">Project Scope: {project.name}</h1>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Affected Rooms</h2>
        <button
          onClick={() => setShowAddRoomForm(true)}
          className="mb-4 bg-blue-500 text-white px-4 py-2 rounded flex items-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Room
        </button>
        {showAddRoomForm && (
          <form onSubmit={(e) => { e.preventDefault(); addRoom(); }} className="mb-4 bg-white p-4 rounded-lg shadow">
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Room Name"
                value={newRoom.name}
                onChange={(e) => setNewRoom({ ...newRoom, name: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Floor Level"
                value={newRoom.floorLevel}
                onChange={(e) => setNewRoom({ ...newRoom, floorLevel: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Length"
                value={newRoom.length}
                onChange={(e) => setNewRoom({ ...newRoom, length: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Width"
                value={newRoom.width}
                onChange={(e) => setNewRoom({ ...newRoom, width: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Height"
                value={newRoom.height}
                onChange={(e) => setNewRoom({ ...newRoom, height: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Offsets greater than 18"
                value={newRoom.offsets}
                onChange={(e) => setNewRoom({ ...newRoom, offsets: e.target.value })}
                className="border p-2 rounded"
              />
              <input
                type="number"
                placeholder="Affected Floor SF"
                value={newRoom.affectedFloorSF}
                onChange={(e) => setNewRoom({ ...newRoom, affectedFloorSF: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Affected Wall SF"
                value={newRoom.affectedWallSF}
                onChange={(e) => setNewRoom({ ...newRoom, affectedWallSF: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Affected Ceiling SF"
                value={newRoom.affectedCeilingSF}
                onChange={(e) => setNewRoom({ ...newRoom, affectedCeilingSF: e.target.value })}
                className="border p-2 rounded"
                required
              />
            </div>
            <button type="submit" className="mt-4 bg-green-500 text-white px-4 py-2 rounded">
              {editingRoomId ? 'Update Room' : 'Add Room'}
            </button>
          </form>
        )}
        <ul className="space-y-4">
          {project.affectedRooms.map(room => (
            <li key={room.id} className="bg-white p-4 rounded-lg shadow">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">{room.name}</h3>
                <div>
                  <button onClick={() => editRoom(room)} className="text-blue-500 mr-2">
                    <Edit className="w-5 h-5" />
                  </button>
                  <button onClick={() => deleteRoom(room.id)} className="text-red-500">
                    <Trash className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <p>Floor Level: {room.floorLevel}</p>
              <p>Dimensions: {room.length}' x {room.width}' x {room.height}'</p>
              <p>Offsets greater than 18": {room.offsets}</p>
              <p>Affected Floor: {room.affectedFloorSF} SF</p>
              <p>Affected Wall: {room.affectedWallSF} SF</p>
              <p>Affected Ceiling: {room.affectedCeilingSF} SF</p>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Services</h2>
        <button
          onClick={() => setShowAddServiceForm(true)}
          className="mb-4 bg-blue-500 text-white px-4 py-2 rounded flex items-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Service
        </button>
        {showAddServiceForm && (
          <form onSubmit={(e) => { e.preventDefault(); addService(); }} className="mb-4 bg-white p-4 rounded-lg shadow">
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Service Description"
                value={newService.description}
                onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="number"
                placeholder="Quantity"
                value={newService.quantity}
                onChange={(e) => setNewService({ ...newService, quantity: e.target.value })}
                className="border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Unit"
                value={newService.unit}
                onChange={(e) => setNewService({ ...newService, unit: e.target.value })}
                className="border p-2 rounded"
                required
              />
            </div>
            <button type="submit" className="mt-4 bg-green-500 text-white px-4 py-2 rounded">
              {editingServiceId ? 'Update Service' : 'Add Service'}
            </button>
          </form>
        )}
        <ul className="space-y-4">
          {project.services.map(service => (
            <li key={service.id} className="bg-white p-4 rounded-lg shadow">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-semibold">{service.description}</h3>
                  <p>{service.quantity} {service.unit}</p>
                </div>
                <div>
                  <button onClick={() => editService(service)} className="text-blue-500 mr-2">
                    <Edit className="w-5 h-5" />
                  </button>
                  <button onClick={() => deleteService(service.id)} className="text-red-500">
                    <Trash className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

export default ProjectScope