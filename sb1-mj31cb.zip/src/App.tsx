import React from 'react'
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom'
import { Home, Clipboard, Settings as SettingsIcon, Camera, FileText, MessageCircle, Box } from 'lucide-react'
import Dashboard from './components/Dashboard'
import ProjectList from './components/ProjectList'
import ProjectDetail from './components/ProjectDetail'
import ProjectPhotos from './components/ProjectPhotos'
import ProjectDocuments from './components/ProjectDocuments'
import ProjectScope from './components/ProjectScope'
import ProjectEquipment from './components/ProjectEquipment'
import ComplianceTaskList from './components/ComplianceTaskList'
import EquipmentList from './components/EquipmentList'
import PhotoManagement from './components/PhotoManagement'
import Reports from './components/Reports'
import SettingsComponent from './components/Settings'
import MessageList from './components/MessageList'
import EquipmentDryingDetails from './components/EquipmentDryingDetails'

const Sidebar = () => {
  const [activeTab, setActiveTab] = React.useState('dashboard')

  const menuItems = [
    { name: 'Dashboard', icon: Home, id: 'dashboard', path: '/' },
    { name: 'Projects', icon: Clipboard, id: 'projects', path: '/projects' },
    { name: 'Compliance', icon: Clipboard, id: 'compliance', path: '/compliance' },
    { name: 'Equipment', icon: Box, id: 'equipment', path: '/equipment' },
    { name: 'Photos', icon: Camera, id: 'photos', path: '/photos' },
    { name: 'Reports', icon: FileText, id: 'reports', path: '/reports' },
    { name: 'Messages', icon: MessageCircle, id: 'messages', path: '/messages' },
    { name: 'Settings', icon: SettingsIcon, id: 'settings', path: '/settings' },
  ]

  return (
    <nav className="bg-blue-600 text-white w-64 space-y-6 py-7 px-2">
      <div className="text-2xl font-semibold text-center mb-6">AquaRestore</div>
      <ul>
        {menuItems.map((item) => (
          <li key={item.id}>
            <Link
              to={item.path}
              className={`flex items-center space-x-2 py-2 px-4 rounded hover:bg-blue-700 w-full ${
                activeTab === item.id ? 'bg-blue-700' : ''
              }`}
              onClick={() => setActiveTab(item.id)}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  )
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100 flex">
        <Sidebar />
        <main className="flex-1 p-10">
          <div className="max-w-4xl mx-auto">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/projects" element={<ProjectList />} />
              <Route path="/project/:id" element={<ProjectDetail />} />
              <Route path="/project/:id/photos" element={<ProjectPhotos />} />
              <Route path="/project/:id/documents" element={<ProjectDocuments />} />
              <Route path="/project/:id/scope" element={<ProjectScope />} />
              <Route path="/project/:id/equipment" element={<ProjectEquipment />} />
              <Route path="/compliance" element={<ComplianceTaskList />} />
              <Route path="/equipment" element={<EquipmentList />} />
              <Route path="/photos" element={<PhotoManagement />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/messages" element={<MessageList />} />
              <Route path="/settings" element={<SettingsComponent />} />
              <Route path="/project/:id/drying-details" element={<EquipmentDryingDetails />} />
            </Routes>
          </div>
        </main>
      </div>
    </Router>
  )
}

export default App